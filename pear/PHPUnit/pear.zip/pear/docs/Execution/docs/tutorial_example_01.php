<?php
require_once 'tutorial_autoload.php';

ezcExecution::init( 'ezcExecutionBasicErrorHandler' );

ezcExecution::cleanExit();
?>
