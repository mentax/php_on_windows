<?php
return array(
    'helloMvcConfiguration' => 'config.php',
    'helloRouter'           => 'router.php',
    'helloController'       => 'controllers/hello.php',
    'helloTestController'   => 'controllers/test.php',
    'helloRootView'         => 'views/root.php',
    'helloNameView'         => 'views/name.php',
    'helloTestView'         => 'views/test.php',
);
?>
