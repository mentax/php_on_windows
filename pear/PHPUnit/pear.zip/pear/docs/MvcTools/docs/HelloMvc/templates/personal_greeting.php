<div id="greeting">
<?php echo $this->greeting, " ", htmlspecialchars( $this->person ); ?>
</div>
<?php
?>
