<div id="greeting">
<?php echo $this->greeting; ?>
</div>
<?php
?>
