<?php

return array(
    'English' => array(
        'Jan 2006' => 965, 
        'Feb 2006' => 1000, 
        'Mar 2006' => 1100,
        'Apr 2006' => 1100, 
        'May 2006' => 1200, 
        'Jun 2006' => 1300,
    ),
    'German' =>  array(
        'Jan 2006' => 357, 
        'Feb 2006' => 371, 
        'Mar 2006' => 387,
        'Apr 2006' => 402, 
        'May 2006' => 429, 
        'Jun 2006' => 435,
    ),
    'Norwegian' => array(
        'Jan 2006' => 49, 
        'Feb 2006' => 52, 
        'Mar 2006' => 56,
        'Apr 2006' => 59, 
        'May 2006' => 63, 
        'Jun 2006' => 67,
    ),
);

?>
